<form class="form-horizontal p-5 shadow h-100" style="background-color:pink;" method="GET" action="Tampilan_BMI.php">
                                <div class="text-center" align="center">
                                  <h3 class="mb-5 text-primary text-black" align="center">Form BMI</h3>
                                </div>
                                <!------------>
                                  <div class="form-group row" align="center">
                                    <label for="namalengkap" class="col-sm-4 col-form-label"><b>Nama</b></label>
                                    <div class="col-sm-8">
                                      <input type="text" class="form-control" name="nama__lengkap" required>
                                    </div>
                                  </div>
                                  <br>
                    
                                <!------------>
                                  <div class="form-group row" align="center">
                                    <label for="namalengkap" class="col-sm-4 col-form-label"><b>Berat Badan</b></label>
                                    <div class="col-sm-6">
                                      <div class="input-group mb-2 mr-sm-2">
                                        <input type="text" class="form-control" name="berat__" required>
                                        <div class="input-group-prepend">
                                          <div class="input-group-text">Kg</div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <br>
                    
                                <!------------>
                                  <div class="form-group row" align="center">
                                    <label for="namalengkap" class="col-sm-4 col-form-label"><b>Tinggi Badan</b></label>
                                    <div class="col-sm-6">
                                      <div class="input-group mb-2 mr-sm-2">
                                        <input type="text" class="form-control" name="tinggi__" required>
                                        <div class="input-group-prepend">
                                          <div class="input-group-text">Cm</div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <br>
                    
                                <!------------>
                                <div class="form-group row" align="center">
                                    <label for="namalengkap" class="col-sm-4 col-form-label"><b>Umur</b></label>
                                    <div class="col-sm-6">
                                      <div class="input-group mb-2 mr-sm-2">
                                        <input type="text" class="form-control" name="umur__" required>
                                        <div class="input-group-prepend">
                                          <div class="input-group-text">Tahun</div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <br>
                    
                                <!------------>
                                <div class="row" align="center">
                                  <legend class="col-form-label col-sm-4 pt-0"><b>Jenis Kelamin</b></legend>
                                  <div class="col-sm-8">
                    
                                    <div class="form-check mr-auto">
                                      <input class="form-check-input" type="radio" id="laki" name="jenis__kelamin" value="Laki-Laki" required>
                                      <label class="form-check-label mr-5" for="laki">
                                        Laki-Laki
                                      </label>
                                      <input class="form-check-input" type="radio" id="perempuan" name="jenis__kelamin" value="Perempuan" required>
                                      <label class="form-check-label" for="perempuan">
                                        Perempuan
                                      </label>
                                    </div>
                                  </div>  <!---col-->
                                </div> <!---row-->
                                <br>
                                <!------------>
                                  <div class="text-center" align="center">
                                    <input class="btn btn-primary" type="submit" value="Simpan" name="proses"/>
                                  </div>
                              </form>
                              <h3>Hasil BMI</h3>
                              <body>
                                <div class="container-fluid" style="max-width:1366px;">    
                                <div class="row">
                                <div class="col-6">
<?php
class BMIpasien {
    public $nama,
           $berat,
           $tinggi,
           $umur,
           $jeniskelamin;

    public function HasilBMI() {
        return "<b>Nama : $this->nama   <br><br>
            Berat Badan : $this->berat <br><br>                  
            Tinggi Badan : $this->tinggi <br><br>
            Umur : $this->umur <br><br>
            Jenis Kelamin : $this->jeniskelamin</b>";
    }

    public function StatusBMI($BMI) {
        }
    }
    if (isset($_GET["nama__lengkap"])){
    
        $BMI = new BMIpasien;
        $BMI->nama=$_GET["nama__lengkap"];
        $BMI->berat=$_GET["berat__"];
        $BMI->tinggi=$_GET["tinggi__"];
        $BMI->umur=$_GET["umur__"];
        $BMI->jeniskelamin=$_GET["jenis__kelamin"];
        echo $BMI->HasilBMI();
    }

?>