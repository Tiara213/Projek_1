<!DOCTYPE html>
<html>
    <head>

    </head>
    <body>
        <footer>
            <div>Copyright &copy; Your Website 2021</div>
                <div>
                    <a href="#">Privacy Policy</a>
                    &middot;
                    <a href="#">Terms &amp; Conditions</a>
                </div>
            </div>
        </footer>
    </body>
        
</html>
